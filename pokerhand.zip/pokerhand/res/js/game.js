
function rand1toN(N) {
   return Math.floor( 1+Math.random()*N );
   }
   
function dealcard(card) {
   var rank = new Array(0,"A","2","3","4","5","6","7",                          
        "8","9","10","J","Q","K");
   var suit = new Array(0, "S", "H", "D", "C");
   card[0] = rank[rand1toN(13)];
   card[1] = suit[rand1toN(4)];
}

function start(){
var card = new Array(2);
var player = new Array(10);
var dealer = new Array(10);
for (var i=0; i<=4; i++) {
   dealcard(card);
   player[i*2] = card[0];
   player[i*2+1] = card[1];
  /* dealcard(card);
   dealer[i*2] = card[0];
   dealer[i*2+1] = card[1];*/
}
document.writeln("<H1> PLAYER CARDS </H1>");
document.writeln("<TABLE BORDER='1' >");
document.writeln("<TR>");
for (var i=0; i<=4; i++) {
   document.writeln("<TD><P> <img src=\"res/i/"+player[i*2]+""+player[i*2+1]+".png\" align=\"middle\" /> </TD>");
   if(player[i*2+1]=="S")
   {
    document.write("<TD><P>"+player[i*2]+" of Spades</TD>");
   }
   else if(player[i*2+1]=="H")
   {
    document.write("<TD><P>"+player[i*2]+" of Hearts</TD>");
   }
   else if(player[i*2+1]=="D")
   {
    document.write("<TD><P>"+player[i*2]+" of Diamonds</TD>");
   }
   else
   {
    document.write("<TD><P>"+player[i*2]+" of Clubs</TD>");
   }
}
document.writeln("</TR>");
document.writeln("</TABLE>");  

}

function poker() {
	start();
 
}
